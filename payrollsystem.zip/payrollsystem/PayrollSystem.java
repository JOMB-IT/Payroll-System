import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PayrollSystem {
    private static final Scanner sc = new Scanner(System.in);

    private static final Path BASE_DIR =
            Paths.get(System.getProperty("user.home"), "PayrollSystemData");
    private static final Path DATA_DIR = BASE_DIR.resolve("data");
    private static final Path REPORT_DIR = BASE_DIR.resolve("reports");
    private static final Path DATA_FILE = DATA_DIR.resolve("payroll-data.bin");

    private static final double SSS_RATE = 0.045;
    private static final double PHILHEALTH_RATE = 0.025;
    private static final double PAGIBIG_RATE = 0.020;
    private static final double TAX_RATE = 0.050;

    private static Store store;

    static class Employee implements Serializable {
        private static final long serialVersionUID = 1L;
        int id;
        String name, position;
        double monthlySalary;
        boolean active = true;

        Employee(int id, String name, String position, double salary) {
            this.id = id;
            this.name = name;
            this.position = position;
            this.monthlySalary = salary;
        }
    }

    static class Attendance implements Serializable {
        private static final long serialVersionUID = 1L;
        int employeeId;
        LocalDate date;
        double overtimeHours;

        Attendance(int id, LocalDate date, double overtimeHours) {
            this.employeeId = id;
            this.date = date;
            this.overtimeHours = overtimeHours;
        }
    }

    static class LeaveRequest implements Serializable {
        private static final long serialVersionUID = 1L;
        int id, employeeId;
        LocalDate startDate, endDate;
        String reason, status = "PENDING";

        LeaveRequest(int id, int employeeId, LocalDate start, LocalDate end,
                     String reason) {
            this.id = id;
            this.employeeId = employeeId;
            this.startDate = start;
            this.endDate = end;
            this.reason = reason;
        }
    }

    static class Payroll implements Serializable {
        private static final long serialVersionUID = 1L;
        int employeeId;
        YearMonth month;
        double basic, overtime, sss, philhealth, pagibig, tax, net;

        Payroll(int employeeId, YearMonth month, double basic, double overtime,
                double sss, double philhealth, double pagibig, double tax) {
            this.employeeId = employeeId;
            this.month = month;
            this.basic = basic;
            this.overtime = overtime;
            this.sss = sss;
            this.philhealth = philhealth;
            this.pagibig = pagibig;
            this.tax = tax;
            this.net = basic + overtime - sss - philhealth - pagibig - tax;
        }
    }

    static class Store implements Serializable {
        private static final long serialVersionUID = 1L;
        Map<Integer, Employee> employees = new LinkedHashMap<>();
        List<Attendance> attendance = new ArrayList<>();
        List<LeaveRequest> leaves = new ArrayList<>();
        List<Payroll> payrolls = new ArrayList<>();

        String salt;
        String passwordHash;
        int nextEmployeeId = 1001;
        int nextLeaveId = 1;
    }

    public static void main(String[] args) {
        try {
            Files.createDirectories(DATA_DIR);
            Files.createDirectories(REPORT_DIR);
            loadData();

            System.out.println("Data file: " + DATA_FILE.toAbsolutePath());


            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try { if (store != null) saveData(); } catch (IOException ignored) { }
            }));

            System.out.println("==================================");
            System.out.println("      PAYROLL SYSTEM");
            System.out.println("       FILE STORAGE");
            System.out.println("==================================");

            if (!login()) {
                System.out.println("Login failed. Exiting.");
                return;
            }

            mainMenu();
        } catch (Exception e) {
            System.out.println("System error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }

    private static void loadData() throws Exception {
        if (Files.exists(DATA_FILE)) {
            try (ObjectInputStream in =
                         new ObjectInputStream(Files.newInputStream(DATA_FILE))) {
                store = (Store) in.readObject();
                return;
            } catch (Exception e) {
                Path backup = DATA_DIR.resolve("payroll-data.corrupt-"
                        + System.currentTimeMillis() + ".bin");
                Files.move(DATA_FILE, backup);
                System.out.println("Could not read saved data (" + e.getMessage() + ").");
                System.out.println("The old file was kept as: " + backup.toAbsolutePath());
            }
        }
        store = new Store();
        setPassword("gelopogi");
        saveData();
        System.out.println("First-time setup complete.");
        System.out.println("Default login: admin");
        System.out.println("Default password: gelopogi");
        System.out.println("Change this password after logging in.");
    }

    private static synchronized void saveData() throws IOException {
        Files.createDirectories(DATA_DIR);
        Path temp = DATA_DIR.resolve("payroll-data.tmp");
        try (ObjectOutputStream out =
                     new ObjectOutputStream(Files.newOutputStream(temp))) {
            out.writeObject(store);
        }
        try {
            Files.move(temp, DATA_FILE, StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(temp, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void setPassword(String password) throws Exception {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        store.salt = Base64.getEncoder().encodeToString(saltBytes);
        store.passwordHash = hashPassword(password, saltBytes);
    }

    private static String hashPassword(String password, byte[] salt)
            throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt,
                120_000, 256);
        try {
            byte[] hash = SecretKeyFactory.getInstance(
                    "PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } finally {
            spec.clearPassword();
        }
    }

    private static boolean login() throws Exception {
        for (int attempt = 1; attempt <= 3; attempt++) {
            System.out.print("Username: ");
            String username = sc.nextLine().trim();
            System.out.print("Password: ");
            String password = sc.nextLine();

            byte[] salt = Base64.getDecoder().decode(store.salt);
            String candidate = hashPassword(password, salt);

            if (username.equals("admin") &&
                    MessageDigest.isEqual(
                            candidate.getBytes(StandardCharsets.UTF_8),
                            store.passwordHash.getBytes(StandardCharsets.UTF_8))) {
                System.out.println("\nLogin successful!\n");
                return true;
            }
            System.out.println("Incorrect username or password. Attempt "
                    + attempt + " of 3.\n");
        }
        return false;
    }

    private static void mainMenu() throws Exception {
        while (true) {
            System.out.println("\n========== MAIN MENU ==========");
            System.out.println("1. Employee management");
            System.out.println("2. Record attendance / overtime");
            System.out.println("3. Manage leave requests");
            System.out.println("4. Generate monthly payroll");
            System.out.println("5. Print / export payslip");
            System.out.println("6. Monthly payroll report");
            System.out.println("0. Save and exit");

            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> employeeMenu();
                case 2 -> recordAttendance();
                case 3 -> leaveMenu();
                case 4 -> generatePayroll();
                case 5 -> exportPayslip();
                case 6 -> monthlyReport();
                case 0 -> {
                    saveData();
                    System.out.println("Data saved. Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void employeeMenu() throws Exception {
        while (true) {
            System.out.println("\n------ EMPLOYEE MANAGEMENT ------");
            System.out.println("1. Add employee");
            System.out.println("2. View employees");
            System.out.println("3. Search employee");
            System.out.println("4. Update employee");
            System.out.println("5. Deactivate employee");
            System.out.println("0. Back");

            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> addEmployee();
                case 2 -> listEmployees();
                case 3 -> searchEmployee();
                case 4 -> updateEmployee();
                case 5 -> deactivateEmployee();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void addEmployee() throws Exception {
        String name = readNonEmpty("Full name: ");
        String position = readNonEmpty("Position: ");
        double salary = readDouble("Monthly basic salary (PHP): ");
        if (salary <= 0) {
            System.out.println("Salary must be greater than zero.");
            return;
        }

        Employee e = new Employee(store.nextEmployeeId++, name, position, salary);
        store.employees.put(e.id, e);
        saveData();
        System.out.println("Employee added. Employee ID: " + e.id);
    }

    private static void listEmployees() {
        System.out.println("\nID     NAME                         POSITION             SALARY       STATUS");
        System.out.println("----------------------------------------------------------------------------");
        for (Employee e : store.employees.values()) {
            System.out.printf("%-6d %-28s %-20s %12.2f   %s%n",
                    e.id, e.name, e.position, e.monthlySalary,
                    e.active ? "ACTIVE" : "INACTIVE");
        }
        if (store.employees.isEmpty()) System.out.println("No employees found.");
    }

    private static Employee findEmployee(int id) {
        return store.employees.get(id);
    }

    private static void searchEmployee() {
        int id = readInt("Employee ID: ");
        Employee e = findEmployee(id);
        if (e == null) {
            System.out.println("Employee not found.");
        } else {
            printEmployee(e);
        }
    }

    private static void printEmployee(Employee e) {
        System.out.println("\nEmployee ID: " + e.id);
        System.out.println("Name: " + e.name);
        System.out.println("Position: " + e.position);
        System.out.printf("Monthly salary: PHP %.2f%n", e.monthlySalary);
        System.out.println("Status: " + (e.active ? "ACTIVE" : "INACTIVE"));
    }

    private static void updateEmployee() throws Exception {
        int id = readInt("Employee ID to update: ");
        Employee e = findEmployee(id);
        if (e == null) {
            System.out.println("Employee not found.");
            return;
        }

        System.out.println("Press Enter to keep the existing value.");
        System.out.print("Name [" + e.name + "]: ");
        String name = sc.nextLine().trim();
        if (!name.isEmpty()) e.name = name;

        System.out.print("Position [" + e.position + "]: ");
        String position = sc.nextLine().trim();
        if (!position.isEmpty()) e.position = position;

        System.out.printf("Monthly salary [%.2f]: ", e.monthlySalary);
        String salaryText = sc.nextLine().trim();
        if (!salaryText.isEmpty()) {
            try {
                double salary = Double.parseDouble(salaryText);
                if (salary > 0) e.monthlySalary = salary;
                else System.out.println("Salary unchanged: must be positive.");
            } catch (NumberFormatException ex) {
                System.out.println("Invalid salary; salary unchanged.");
            }
        }
        saveData();
        System.out.println("Employee updated.");
    }

    private static void deactivateEmployee() throws Exception {
        int id = readInt("Employee ID to deactivate: ");
        Employee e = findEmployee(id);
        if (e == null) {
            System.out.println("Employee not found.");
            return;
        }
        e.active = false;
        saveData();
        System.out.println("Employee deactivated.");
    }

    private static void recordAttendance() throws Exception {
        int id = readInt("Employee ID: ");
        Employee e = findEmployee(id);
        if (e == null || !e.active) {
            System.out.println("Active employee not found.");
            return;
        }

        LocalDate date = readDate("Attendance date (YYYY-MM-DD): ");
        double overtime = readDouble("Overtime hours (0 if none): ");
        if (overtime < 0 || overtime > 24) {
            System.out.println("Overtime hours must be between 0 and 24.");
            return;
        }

        for (Attendance a : store.attendance) {
            if (a.employeeId == id && a.date.equals(date)) {
                a.overtimeHours = overtime;
                saveData();
                System.out.println("Attendance updated.");
                return;
            }
        }

        store.attendance.add(new Attendance(id, date, overtime));
        saveData();
        System.out.println("Attendance recorded.");
    }

    private static void leaveMenu() throws Exception {
        while (true) {
            System.out.println("\n--------- LEAVE MANAGEMENT ---------");
            System.out.println("1. Submit leave request");
            System.out.println("2. View leave requests");
            System.out.println("3. Approve / reject request");
            System.out.println("0. Back");

            int choice = readInt("Choose an option: ");
            switch (choice) {
                case 1 -> submitLeave();
                case 2 -> viewLeaves();
                case 3 -> processLeave();
                case 0 -> { return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void submitLeave() throws Exception {
        int id = readInt("Employee ID: ");
        Employee e = findEmployee(id);
        if (e == null || !e.active) {
            System.out.println("Active employee not found.");
            return;
        }

        LocalDate start = readDate("Start date (YYYY-MM-DD): ");
        LocalDate end = readDate("End date (YYYY-MM-DD): ");
        if (end.isBefore(start)) {
            System.out.println("End date cannot be before start date.");
            return;
        }
        String reason = readNonEmpty("Reason for leave: ");

        LeaveRequest leave = new LeaveRequest(
                store.nextLeaveId++, id, start, end, reason);
        store.leaves.add(leave);
        saveData();
        System.out.println("Leave request submitted. Request ID: " + leave.id);
    }

    private static void viewLeaves() {
        if (store.leaves.isEmpty()) {
            System.out.println("No leave requests.");
            return;
        }
        for (LeaveRequest l : store.leaves) {
            Employee e = findEmployee(l.employeeId);
            System.out.printf("Request #%d | Employee: %s (ID %d) | %s to %s | %s | %s%n",
                    l.id, e == null ? "Unknown" : e.name, l.employeeId,
                    l.startDate, l.endDate, l.status, l.reason);
        }
    }

    private static void processLeave() throws Exception {
        viewLeaves();
        int requestId = readInt("Request ID to process: ");
        LeaveRequest target = null;
        for (LeaveRequest l : store.leaves) {
            if (l.id == requestId) target = l;
        }
        if (target == null) {
            System.out.println("Request not found.");
            return;
        }
        if (!target.status.equals("PENDING")) {
            System.out.println("This request has already been processed.");
            return;
        }

        System.out.print("Type A to approve or R to reject: ");
        String choice = sc.nextLine().trim().toUpperCase(Locale.ROOT);
        if (choice.equals("A")) target.status = "APPROVED";
        else if (choice.equals("R")) target.status = "REJECTED";
        else {
            System.out.println("Invalid choice.");
            return;
        }
        saveData();
        System.out.println("Request " + target.status.toLowerCase(Locale.ROOT) + ".");
    }

    private static void generatePayroll() throws Exception {
        YearMonth month = readMonth("Payroll month (YYYY-MM): ");
        int count = 0;

        for (Employee e : store.employees.values()) {
            if (!e.active) continue;

            boolean alreadyExists = false;
            for (Payroll p : store.payrolls) {
                if (p.employeeId == e.id && p.month.equals(month)) {
                    alreadyExists = true;
                    break;
                }
            }
            if (alreadyExists) {
                System.out.println("Payroll already exists for " + e.name
                        + ". Skipping to avoid duplicate.");
                continue;
            }

            double overtimeHours = 0;
            for (Attendance a : store.attendance) {
                if (a.employeeId == e.id &&
                        YearMonth.from(a.date).equals(month)) {
                    overtimeHours += a.overtimeHours;
                }
            }

            double hourlyRate = e.monthlySalary / 22.0 / 8.0;
            double overtimePay = overtimeHours * hourlyRate * 1.25;
            double gross = e.monthlySalary + overtimePay;

            double sss = gross * SSS_RATE;
            double philhealth = gross * PHILHEALTH_RATE;
            double pagibig = gross * PAGIBIG_RATE;
            double tax = gross * TAX_RATE;

            Payroll p = new Payroll(e.id, month, e.monthlySalary,
                    overtimePay, sss, philhealth, pagibig, tax);
            store.payrolls.add(p);
            count++;
            System.out.printf("Created payroll for %s (ID %d): net PHP %.2f%n",
                    e.name, e.id, p.net);
        }

        saveData();
        System.out.println("Payroll generation complete. New records: " + count);
        System.out.println("Note: Demo calculations do not adjust salary for absences or leave.");
    }

    private static void exportPayslip() throws Exception {
        int id = readInt("Employee ID: ");
        YearMonth month = readMonth("Payslip month (YYYY-MM): ");

        Payroll found = null;
        for (Payroll p : store.payrolls) {
            if (p.employeeId == id && p.month.equals(month)) found = p;
        }
        if (found == null) {
            System.out.println("Payroll record not found. Generate payroll first.");
            return;
        }

        Employee e = findEmployee(id);
        String content = payslipText(e, found);
        System.out.println("\n" + content);

        Path file = REPORT_DIR.resolve("payslip_" + id + "_" + month + ".txt");
        Files.writeString(file, content, StandardCharsets.UTF_8);
        System.out.println("Payslip saved to: " + file.toAbsolutePath());
    }

    private static String payslipText(Employee e, Payroll p) {
        return """
                ==========================================
                            EMPLOYEE PAYSLIP
                ==========================================
                Payroll Month: %s
                Employee ID:  %d
                Employee Name: %s
                Position: %s
                ------------------------------------------
                EARNINGS
                Basic Salary:              PHP %10.2f
                Overtime Pay:              PHP %10.2f
                Gross Pay:                 PHP %10.2f
                ------------------------------------------
                DEMO DEDUCTIONS
                SSS (4.5%%):                PHP %10.2f
                PhilHealth (2.5%%):         PHP %10.2f
                Pag-IBIG (2.0%%):           PHP %10.2f
                Tax (5.0%%):                PHP %10.2f
                Total Deductions:           PHP %10.2f
                ------------------------------------------
                NET PAY:                    PHP %10.2f
                ==========================================
                NOTE: DEMO payroll calculation only.
                Verify applicable laws and rates before real use.
                """.formatted(
                p.month, e == null ? p.employeeId : e.id,
                e == null ? "Unknown" : e.name,
                e == null ? "Unknown" : e.position,
                p.basic, p.overtime, p.basic + p.overtime,
                p.sss, p.philhealth, p.pagibig, p.tax,
                p.sss + p.philhealth + p.pagibig + p.tax, p.net);
    }

    private static void monthlyReport() throws Exception {
        YearMonth month = readMonth("Report month (YYYY-MM): ");
        StringBuilder report = new StringBuilder();
        report.append("MONTHLY PAYROLL REPORT\n");
        report.append("Month: ").append(month).append("\n");
        report.append("====================================================\n");
        report.append(String.format("%-6s %-24s %12s %12s%n",
                "ID", "EMPLOYEE", "GROSS", "NET PAY"));

        double totalGross = 0, totalNet = 0;
        int count = 0;

        for (Payroll p : store.payrolls) {
            if (!p.month.equals(month)) continue;
            Employee e = findEmployee(p.employeeId);
            String name = e == null ? "Unknown" : e.name;
            double gross = p.basic + p.overtime;
            report.append(String.format("%-6d %-24s %12.2f %12.2f%n",
                    p.employeeId, name, gross, p.net));
            totalGross += gross;
            totalNet += p.net;
            count++;
        }

        report.append("====================================================\n");
        report.append(String.format("Employees processed: %d%n", count));
        report.append(String.format("Total gross pay: PHP %.2f%n", totalGross));
        report.append(String.format("Total net pay:   PHP %.2f%n", totalNet));
        report.append("\nDEMO rates: SSS 4.5%, PhilHealth 2.5%, ");
        report.append("Pag-IBIG 2%, Tax 5%.\n");
        report.append("Verify current rules before using for actual payroll.\n");

        System.out.println("\n" + report);
        Path file = REPORT_DIR.resolve("payroll_report_" + month + ".txt");
        Files.writeString(file, report.toString(), StandardCharsets.UTF_8);
        System.out.println("Report saved to: " + file.toAbsolutePath());
    }

    private static void changePassword() throws Exception {
        System.out.print("Current password: ");
        String current = sc.nextLine();
        byte[] salt = Base64.getDecoder().decode(store.salt);
        String candidate = hashPassword(current, salt);

        if (!MessageDigest.isEqual(
                candidate.getBytes(StandardCharsets.UTF_8),
                store.passwordHash.getBytes(StandardCharsets.UTF_8))) {
            System.out.println("Incorrect current password.");
            return;
        }

        System.out.print("New password (at least 8 characters): ");
        String next = sc.nextLine();
        if (next.length() < 8) {
            System.out.println("Password must be at least 8 characters.");
            return;
        }
        System.out.print("Confirm new password: ");
        String confirm = sc.nextLine();
        if (!next.equals(confirm)) {
            System.out.println("Passwords do not match.");
            return;
        }

        setPassword(next);
        saveData();
        System.out.println("Password changed successfully.");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            try {
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = sc.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private static LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return LocalDate.parse(sc.nextLine().trim());
            } catch (DateTimeParseException e) {
                System.out.println("Use the format YYYY-MM-DD.");
            }
        }
    }

    private static YearMonth readMonth(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return YearMonth.parse(sc.nextLine().trim());
            } catch (DateTimeParseException e) {
                System.out.println("Use the format YYYY-MM.");
            }
        }
    }
}